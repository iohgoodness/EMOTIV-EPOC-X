find_service
------------
.. currentmodule:: bluetooth

.. autofunction:: find_service