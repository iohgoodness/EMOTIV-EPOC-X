discover_devices
----------------
.. currentmodule:: bluetooth

.. autofunction:: discover_devices